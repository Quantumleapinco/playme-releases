# Puts Nagenli on a Samsung TV that is in Developer Mode. Started by "Install Nagenli on TV.bat".
# It changes nothing on this computer: it only talks to the TV with Samsung's own tool (tools\sdb.exe).
$ErrorActionPreference = 'Continue'
$here = Split-Path -Parent $MyInvocation.MyCommand.Path
$sdb = Join-Path $here 'tools\sdb.exe'
$wgt = Join-Path $here 'Nagenli.wgt'
$app = 'NagenliTV0.Nagenli'

function Stop-Here([string]$text) {
    Write-Host ''
    Write-Host $text -ForegroundColor Yellow
    Write-Host ''
    Read-Host 'Press Enter to close'
    exit 1
}

Write-Host ''
Write-Host '  Nagenli for Samsung TV' -ForegroundColor Magenta
Write-Host ''
if (-not (Test-Path $sdb) -or -not (Test-Path $wgt)) { Stop-Here 'Files are missing. Extract the whole zip to a folder first, then run this again.' }

# This computer's addresses on the home network: one of them is what the TV asks for as "Host PC IP".
$mine = @(Get-NetIPAddress -AddressFamily IPv4 -ErrorAction SilentlyContinue |
    Where-Object { $_.IPAddress -match '^(10\.|192\.168\.|172\.(1[6-9]|2\d|3[01])\.)' -and $_.PrefixOrigin -ne 'WellKnown' } |
    ForEach-Object { $_.IPAddress })
Write-Host "This computer's address (the TV's `"Host PC IP`"): $($mine -join '  or  ')"
Write-Host ''

# Looks for televisions in Developer Mode: they listen on port 26101.
function Find-Tvs {
    $found = @()
    foreach ($ip in $mine) {
        $net = $ip.Substring(0, $ip.LastIndexOf('.') + 1)
        $tries = foreach ($n in 1..254) {
            $c = New-Object Net.Sockets.TcpClient
            [pscustomobject]@{ Ip = "$net$n"; Client = $c; Task = $c.ConnectAsync("$net$n", 26101) }
        }
        Start-Sleep -Milliseconds 1500
        foreach ($t in $tries) {
            if ($t.Task.Status -eq 'RanToCompletion' -and $t.Client.Connected) { $found += $t.Ip }
            $t.Client.Close()
        }
    }
    $found | Select-Object -Unique
}

Write-Host 'Looking for the TV...'
$tvs = @(Find-Tvs)
if ($tvs.Count -eq 1) {
    $tv = $tvs[0]
    Write-Host "Found a TV at $tv"
} else {
    if ($tvs.Count -gt 1) { Write-Host "Found several: $($tvs -join ', ')" } else { Write-Host 'No TV answered. Is it on, and is Developer Mode on (see the instructions)?' }
    $tv = (Read-Host "Type the TV's address (TV: Settings > General > Network > Network Status > IP Settings)").Trim()
    if (-not $tv) { Stop-Here 'No address given.' }
}
$target = "${tv}:26101"

& $sdb connect $target | Out-Null
Start-Sleep -Seconds 2
$state = (& $sdb devices | Select-String ([regex]::Escape($target)) | Select-Object -First 1)
if (-not $state -or "$state" -notmatch '\bdevice\b') {
    & $sdb disconnect $target | Out-Null
    Stop-Here @"
The TV at $tv did not let this computer in.
On the TV: Apps > press 1 2 3 4 5 on the remote > Developer Mode ON > Host PC IP = $($mine | Select-Object -First 1)
Then hold the power button until the TV restarts, and run this again.
"@
}

$duid = ("" + (& $sdb -s $target shell 0 getduid)).Trim()
Write-Host "TV code (DUID): $duid"
Write-Host ''
Write-Host 'Installing Nagenli (about half a minute)...'

# Where the TV takes packages from; every Samsung TV says so itself.
$toolpath = '/home/owner/share/tmp/sdk_tools'
foreach ($line in (& $sdb -s $target capability)) { if ($line -match '^sdk_toolpath:(.+)$') { $toolpath = $Matches[1].Trim() } }
& $sdb -s $target push $wgt "$toolpath/tmp/Nagenli.wgt" | Out-Null
$out = (& $sdb -s $target shell 0 vd_appinstall $app "$toolpath/tmp/Nagenli.wgt" 2>&1 | Out-String)

if ($out -match 'install completed' -and $out -notmatch 'fail') {
    & $sdb -s $target shell 0 was_execute $app | Out-Null
    Write-Host ''
    Write-Host 'Nagenli is on the TV. It is opening now; next time it is in Apps.' -ForegroundColor Green
    Write-Host ''
    Read-Host 'Press Enter to close'
    exit 0
}

$model = ("" + (& $sdb -s $target capability | Where-Object { $_ -match '^(product_version|platform_version|profile_name):' }) -join '  ').Trim()
$report = "Nagenli TV install refused`r`nTV code (DUID): $duid`r`nTV: $model`r`n$($out.Trim())"
$report | Set-Clipboard
Stop-Here @"
The TV refused the app. This is what it answered:
$($out.Trim())

Some Samsung TVs take only apps signed for that one TV. Send these lines to the person who invited you
(they were copied, just paste them in a message):

    TV code (DUID): $duid
    TV: $model

They will tell you what to do next.
"@
